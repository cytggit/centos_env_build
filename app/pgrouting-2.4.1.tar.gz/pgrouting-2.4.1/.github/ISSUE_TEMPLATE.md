### Expected behavior and actual behavior


### Steps to reproduce the problem


### Specifications like the version of pgRouting/PostGIS and PostgreSQL as well as Operating System

Use the commands:
```
SELECT version();
SELECT postgis_full_version();
SELECT pgr_version();
```

