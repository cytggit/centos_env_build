..
   ****************************************************************************
    pgRouting Manual
    Copyright(c) pgRouting Contributors

    This documentation is licensed under a Creative Commons Attribution-Share
    Alike 3.0 License: http://creativecommons.org/licenses/by-sa/3.0/
   ****************************************************************************


.. _KSP:

KSP Category
===============================================================================

.. index from here

* :ref:`pgr_KSP` - Driving Distance based on pgr_dijkstra
* :ref:`pgr_withPointsKSP` - Driving Distance based on pgr_dijkstra

.. index to here


